# NativeClient-DotNet
A WPF application that signs users in and calls the Azure AD Graph API
