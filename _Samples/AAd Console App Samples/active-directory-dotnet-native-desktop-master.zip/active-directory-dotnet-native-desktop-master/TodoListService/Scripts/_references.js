﻿/// <autosync enabled="true" />
/// <reference path="bootstrap.js" />
/// <reference path="jquery-1.10.2.js" />
/// <reference path="jquery-2.1.1.js" />
/// <reference path="modernizr-2.6.2.js" />
/// <reference path="respond.js" />
/// <reference path="respond.matchmedia.addlistener.js" />
